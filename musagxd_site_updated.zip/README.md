
# MUSAGXD — Website (Drake/OVO-Inspired)

A clean, luxury, dark-themed site for music, merch, and tour dates. Static site: just upload to Netlify, Vercel, or GitHub Pages.

## 🔧 Quick Start
1. Unzip and open `index.html` in your browser.
2. Edit `index.html` text and links.
3. Update `tours.json` with real shows.
4. Deploy to the web (Netlify recommended).

## 🎵 Music Embeds
- **Spotify:** Replace the `src` in the Spotify `<iframe>` with Musagxd’s real Spotify artist/album/playlist embed URL.
- **Apple Music:** Replace the Apple Music `src` with the correct embed.
- **YouTube:** Swap the video URL with the latest video ID.

## 🛒 Merch Integration (Shopify Buy Button)
1. In Shopify Admin: Sales Channels → Buy Button → Create Buy Button (for product or collection).
2. Copy the generated script + div snippet.
3. In `index.html`, paste it inside the **Merch** section (you can replace the sample product cards).
4. Or, replace the `alert(...)` in `assets/js/app.js` with the Buy Button SDK init code.

**Printful/Printify:** You can embed the storefront widget or link checkout URLs to the product buttons.

## 🎫 Tour Dates
- Edit `tours.json`. Each show entry:
```json
{
  "date": "2025-09-12",
  "city": "New Orleans, LA",
  "venue": "House of Blues",
  "tickets": "https://tickets-link",
  "map": "https://maps.apple.com/?q=Venue+Name"
}
```
- The list auto-sorts by date.

## ✉️ Email Capture
- Currently opens a **mailto** to `musagxd@gmail.com`.
- For a backend-free option, use **Formspree** or **Netlify Forms**:
  - Replace the `notify` submit handler in `assets/js/app.js` with a `fetch('https://formspree.io/f/xxxx', { method:'POST', body: new FormData(form) })`.
  - Or add `netlify` attributes to the form and deploy on Netlify.

## 🔤 Fonts & Branding
- Uses **Inter** + **Bodoni Moda**. Colors are black/white with **gold** accents (`#c8a142`). Tweak in `assets/css/styles.css`.

## 🚀 Deploy
- **Netlify:** Drag-and-drop the folder in Netlify dashboard. Set site name to `musagxd.com` (after buying domain).
- **Vercel:** `Import Project` → upload.
- **GitHub Pages:** Push repo and enable Pages.
- **Custom Domain:** Point DNS `A`/`CNAME` per host docs.

## 📂 Structure
```
/assets
  /css/styles.css
  /js/app.js
  /img
  /epk/MUSAGXD_EPK.pdf
index.html
tours.json
```

## 🧪 Accessibility
- High contrast colors, focusable buttons, semantic headings, `aria-live` for tour list.

## 📌 Notes
- Replace placeholder images in `/assets/img` with real photos/product shots.
- This is static and fast; no server required.

— Built 2025-08-24
