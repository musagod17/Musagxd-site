
// Year in footer
document.getElementById('year').textContent = new Date().getFullYear();

// Load tour dates
async function loadTours(){
  try{
    const res = await fetch('tours.json');
    const data = await res.json();
    const container = document.getElementById('tour-list');
    container.innerHTML = '';
    if(!data.length){
      container.innerHTML = '<p>No upcoming dates yet — tap Notify Me and we\'ll email when we add your city.</p>';
      return;
    }
    // Sort by date ascending
    data.sort((a,b)=> new Date(a.date) - new Date(b.date));
    for(const show of data){
      const row = document.createElement('div');
      row.className = 'tour-item';
      const when = new Date(show.date);
      const options = {weekday:'short', year:'numeric', month:'short', day:'numeric'};
      row.innerHTML = \`
        <div>
          <strong>\${show.city}</strong> • \${show.venue}<br>
          <small>\${when.toLocaleDateString(undefined, options)}</small>
        </div>
        <a class="btn btn--ghost" href="\${show.map}" target="_blank" rel="noopener">Map</a>
        <a class="btn btn--gold" href="\${show.tickets}" target="_blank" rel="noopener">Tickets</a>
      \`;
      container.appendChild(row);
    }
  }catch(e){
    console.error(e);
  }
}
loadTours();

// Simple fake checkout / Shopify hook
document.addEventListener('click', (e)=>{
  const t = e.target;
  if(t.matches('[data-action="buy"]')){
    const sku = t.getAttribute('data-sku');
    // Replace this with Shopify Buy Button JS or your provider's checkout URL
    alert('Connect your Shopify/Printful checkout for SKU: ' + sku + '\nSee README for setup.');
  }
});

// Email capture (no backend) - sends to mailto or Formspree
document.getElementById('notify').addEventListener('submit', (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const email = fd.get('email');
  const city  = fd.get('city') || '';
  // QUICK OPTION: mailto (opens client)
  window.location.href = 'mailto:musagxd@gmail.com?subject=Tour%20Alert%20Signup&body=' + encodeURIComponent('Email: ' + email + '\nCity: ' + city);
  // For Formspree/Netlify, see README to replace with fetch()
});
